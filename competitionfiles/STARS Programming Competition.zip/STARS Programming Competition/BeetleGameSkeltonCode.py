import random#import the classe random 
"""the beetle class"""
class Beetle:
    position = (0,0)#always starts at 0

"""This function contrls the pattern that the beetle would move"""
def moveBeetle(beetle, board):#for the moment we will only have the beetle move in a simple pattern
        x = beetle.position[0];#make some place holders for positions
        y = beetle.position[1];
        board.game_board[x][y] = 0#erases the beetle from the board
        #SIMPLEST RANDOM POSITION CHOOSER
        
        sentinal = True
        while(sentinal):#will continue to execute until a decision is made
            choice = random.randint(1,4)
            if((choice == 1)and((x+1)<5)):#first if statement is to make sure the beetle doesn't leave the board
                x += 1
            elif((choice == 2)and((x-1)>=0)):
                x -= 1
                sentinal = False
            elif((choice == 3)and((y+1)<5)):
                y += 1
                sentinal = False
            elif((choice == 4)and((y-1)>=0)):
                y -= 1
                sentinal = False
        board.used_spaces[x][y] = 1#updates the board with the new used space
        board.game_board[x][y] = 'X'#paces the beetle down on the game board
        beetle.position = (x,y)
        #THIS PATTER WIL JUST MOVE THE BEETLE DOWN THE BOARD LINE BY LINE
        """
        if(y<4):
            y += 1
        else:
            x += 1
            y = 0
        """
        board.used_spaces[x][y] = 1 #updates the board with the new used space
        board.game_board[x][y] = 'X'#paces the beetle down on the game board
        beetle.position = (x,y)
        return (x,y)
"""BOARD CLASS"""
class Board:
    game_board = [[0]*5 for x in range(5)]#makes the 5x5 board that will be played
    game_board[0][0] = 'X'#X marks the position of the beetle
    goal_space = ((),)  #makes the empty tuple to hold coordinates
    used_spaces = [[0]*5 for x in range(5)] #makes an empty 5x5 board that will tell if the position was already moved on
    used_spaces[0][0] = 1#puts the starting position as taken
    probability_board = [[1/24]*5 for x in range(5)]#each position gets 1/24 besides the startng space
    probability_board[0][0] = 0
    goal_space = ((),)

"""function to disperse the probability values of the space"""
def prob_dispersion(board, position):
    a = int(position // 5)
    b = int(position % 5)
    disperse_num = 4
    value = board.probability_board[a][b]#gets the value of the previous
    board.probability_board[a][b] = 0 #sets the prob = 0
    exception = " "
    #HOPEFULLY THIS METHOD TO DISPERSE THE PROBABILITY WILL BECOME MORE EFFICIENT DOWN THE LINE
    #RIGHT NOW I'M JUST WORKING TO GET THIS FUNCTIONAL
    
    """THIS SERIES OF IF STATEMENTS CHECKS AND ASSIGNS THE POSITION OF THE GOAL SPACE"""    
    #checks to see if the space is BOTTOM RIGHT
    if((a+1 == 5) and (b+1 == 5)):
        exception = "BR"#asigns the exception tag
        disperse_num = disperse_num-2#adjusts the dispersion
    #cheks to see if the space is in the BOTTOM LEFT
    elif((a+1 == 5) and(b-1 == -1)):
        exception = "BL"
        disperse_num = disperse_num - 2
    #checks to see if the space is in the UPPER RIGHT
    elif((a-1 == -1) and (b+1 == 5)):
        exception = "UR"
        disperse_num = disperse_num -2
    #checks to see if the space is in the UPPER LEFT
    elif((a-1 == -1) and (b-1 == -1)):
        exception = "UL"
        disperse_num = disperse_num -2
    #checks to see if the space is in the RIGHT EDGE
    elif(b+1 == 5):
        exception = "R"
        disperse_num = disperse_num -1 #these positions still have three squares to disperse info
    #checks to see if the space is in the LEFT EDGE
    elif(b-1 == -1):
        exception = "L"
        disperse_num = disperse_num -1
    #checks to see if the space is in the UPPER EDGE
    elif(a-1 == -1):
        exception = "U"
        disperse_num = disperse_num -1
    #checks to see if the space is in the BOTTOM EDGE
    elif(a+1 == 5):
        exception = "L"
        disperse_num = disperse_num -1

    """THIS SERIES OF IF STATEMENTS HOLDS THE ACTUAL DISPERSIONS BASED ON THE INFO FROM THE PREVIOUS SECTION"""
    if(exception[0] == "U"):#WILL DEAL WITH ANY POSITIONS AT THE TOP OF THE BOARD
         if(len(exception) == 2):
             if(exception[1] == "R"):#UPPER RIGHT CORNER OF THE BOARD
                 board.probability_board[a][b-1] += value/disperse_num
                 board.probability_board[a+1][b] += value/disperse_num
             elif(exception[1] == "L"):#UPPER LEFT CORNER OF THE BOARD
                 board.probability_board[a][b+1] += value/disperse_num
                 board.probability_board[a+1][b] += value/disperse_num
         else:#ANY UPPER BOUD SPACE THAT IS NOT A CORNER
             board.probability_board[a][b-1] += value/disperse_num
             board.probability_board[a][b+1] += value/disperse_num
             board.probability_board[a+1][b] += value/disperse_num
    elif(exception[0] == "B"):#WILL DEAL WIHT ANY OF THE POSITIONS AT THE BOTTOM OF THE BOARD
         if(len(exception) == 2):
             if(exception[1] == "R"):#BOTTOM RIGHT CORNER OF THE BOARD
                 board.probability_board[a][b-1] += value/disperse_num
                 board.probability_board[a-1][b] += value/disperse_num
             elif(exception[1] == "L"):#BOTTOM LEFT CORNER OF THE BOARD
                 board.probability_board[a][b+1] += value/disperse_num
                 board.probability_board[a-1][b] += value/disperse_num
         else:#ANY BOTTOM BOUND SPACE THAT IS NOT A CORNER
             board.probability_board[a][b-1] += value/disperse_num
             board.probability_board[a][b+1] += value/disperse_num
             board.probability_board[a-1][b] += value/disperse_num
    elif(exception[0] == "R"):#WILL DEAL WITH THE RIGHT EDGE SPACES, NOT CORNERS
         board.probability_board[a][b-1] += value/disperse_num
         board.probability_board[a+1][b] += value/disperse_num
         board.probability_board[a-1][b] += value/disperse_num
    elif(exception[0] == "L"):#WILL DEAL WITH THE LEFT EDGE OF THE BOARD, NOT CORNERS
         board.probability_board[a][b-1] += value/disperse_num
         board.probability_board[a][b+1] += value/disperse_num
         board.probability_board[a-1][b] += value/disperse_num
    else:#SHOULD DEAL WITH 0 EXCEPTIONS, DISPERSION IS MADE BETWEEN 4 SQUARES
         board.probability_board[a][b-1] += value/disperse_num
         board.probability_board[a][b+1] += value/disperse_num
         board.probability_board[a-1][b] += value/disperse_num
         board.probability_board[a+1][b] += value/disperse_num

"""Creates an array that holds the cdf values of each space"""
def cdf(prob_board):
    cdf_array = []#creates a 1D array to store the cdf values
    total = 0 #the total of the probs so that a cdf could be built
    num = 0 #keeps track of which space the cdf goes to
    for i in range(5):
        for j in range(5):
            total += prob_board[i][j]#adds the probabilites
            tup = (num,total)#creates tuple for the array
            cdf_array.append(tup)#adds the tuples
            num +=1#increments the space number
    return cdf_array      

"""returns the space that the goal space will go to, relies on the cdf function"""
def prob_space(prob_board):
    num = 0
    found = False
    rand = random.random()#makes a random number 0-1
    array = cdf(prob_board)#creates the cdf array
    #print(array)
    while(not found):
        tup = array[num]#cdf is a list of tuples-starts at 0 and moves up the array
        if(rand<tup[1]):#if the random value is less than the cdf value you've found the space
            found = True
        else:
            num+=1#increments the space number
    return num

"""SETS THE POSITION OF THE GOAL SPACE"""
def setSpace(board, turns):
    space_num = prob_space(board.probability_board)
    a = int(space_num // 5)#column
    b = int(space_num % 5)#row
    while(board.used_spaces[a][b] == 1):#if the position was already moved to by the beetle it won't go there
        space_num = prob_space(board.probability_board)
        a = int(space_num // 5)#column
        b = int(space_num % 5)#row
    board.game_board[a][b] = 'Y'#places the goal space as Y at position (a,b)
    if(turns>0):
        i = board.goal_space[0]
        j = board.goal_space[1]
        board.game_board[i][j] = 0  #resets the previous goal space position
    board.goal_space = (a,b)
    prob_dispersion(board, space_num)

"""PRINTS AN ARRAY IN THE GRID FORM"""
def arrayprint(array):
    for x in array:
        print(x)

"""MAIN GAME DRIVER"""
def GamePlay(board, beetle):
    turns = 0
    goal_found = 0
    print("Board:") #prints out the game board
    arrayprint(board.game_board)
    while(goal_found == 0):
        print()
        print("------------------------------------")
        setSpace(board, turns)  #set the goal space
        moveBeetle(beetle,board)    #moves the beetle
        if(beetle.position == board.goal_space):#should check the two positions
            goal_found +=1 #if the positions are teh same kill the game
        print("Board:") #prints out the game board
        arrayprint(board.game_board)
        """
        print()
        print("Previous Positions:")#prints out the positions that have been moved to
        arrayprint(board.used_spaces)
        print()
        print("Probability Board:")
        arrayprint(board.probability_board)
        """
        turns +=1
        print("turn: ",turns)
    print("You beat the game in ",turns," turns!")

p1 = Beetle()
p2 = Board()
GamePlay(p2,p1)



    
    


